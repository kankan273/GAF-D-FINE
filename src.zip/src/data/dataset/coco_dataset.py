"""
Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
Mostly copy-paste from https://github.com/pytorch/vision/blob/13b35ff/references/detection/coco_utils.py

Copyright(c) 2023 lyuwenyu. All Rights Reserved.

Modified for custom COCO-style datasets:
- Uses category ids from the current annotation JSON instead of MS COCO 80-class mapping.
- Supports category ids such as 0..6 or 1..7 by mapping them internally to labels 0..N-1.
"""

import os

import faster_coco_eval.core.mask as coco_mask
from faster_coco_eval.utils.pytorch import FasterCocoDetection
import torch
import torchvision
from PIL import Image

from ...core import register
from .._misc import convert_to_tv_tensor
from ._dataset import DetDataset

torchvision.disable_beta_transforms_warning()
Image.MAX_IMAGE_PIXELS = None

__all__ = ["CocoDetection"]


@register()
class CocoDetection(FasterCocoDetection, DetDataset):
    __inject__ = [
        "transforms",
    ]
    __share__ = ["remap_mscoco_category"]

    def __init__(
        self,
        img_folder,
        ann_file,
        transforms,
        return_masks=False,
        remap_mscoco_category=False,
    ):
        super(FasterCocoDetection, self).__init__(img_folder, ann_file)
        self._transforms = transforms
        self.prepare = ConvertCocoPolysToMask(return_masks)
        self.img_folder = img_folder
        self.ann_file = ann_file
        self.return_masks = return_masks
        self.remap_mscoco_category = remap_mscoco_category

        # Build category mapping from the current JSON file instead of MS COCO.
        # Example 1: categories.id = [0,1,2,3,4,5,6]
        #     category2label = {0:0, 1:1, ..., 6:6}
        # Example 2: categories.id = [1,2,3,4,5,6,7]
        #     category2label = {1:0, 2:1, ..., 7:6}
        cats = self.coco.loadCats(self.coco.getCatIds())
        cats = sorted(cats, key=lambda x: x["id"])
        self._category2label = {cat["id"]: i for i, cat in enumerate(cats)}
        self._label2category = {i: cat["id"] for i, cat in enumerate(cats)}

        print("[CocoDetection] ann_file:", self.ann_file)
        print("[CocoDetection] category2label:", self._category2label)
        print("[CocoDetection] label2category:", self._label2category)

    def __getitem__(self, idx):
        img, target = self.load_item(idx)
        if self._transforms is not None:
            img, target, _ = self._transforms(img, target, self)
        return img, target

    def load_item(self, idx):
        image, target = super(FasterCocoDetection, self).__getitem__(idx)
        image_id = self.ids[idx]
        image_info = self.coco.loadImgs(image_id)[0]
        image_path = os.path.join(self.img_folder, image_info["file_name"])
        target = {"image_id": image_id, "image_path": image_path, "annotations": target}

        # Always use the mapping from the current annotation JSON.
        # Do not use mscoco_category2label for custom datasets.
        image, target = self.prepare(
            image,
            target,
            category2label=self.category2label,
        )

        target["idx"] = torch.tensor([idx])

        if "boxes" in target:
            target["boxes"] = convert_to_tv_tensor(
                target["boxes"], key="boxes", spatial_size=image.size[::-1]
            )

        if "masks" in target:
            target["masks"] = convert_to_tv_tensor(target["masks"], key="masks")

        return image, target

    def extra_repr(self) -> str:
        s = f" img_folder: {self.img_folder}\n ann_file: {self.ann_file}\n"
        s += f" return_masks: {self.return_masks}\n"
        if hasattr(self, "_transforms") and self._transforms is not None:
            s += f" transforms:\n   {repr(self._transforms)}"
        if hasattr(self, "_preset") and self._preset is not None:
            s += f" preset:\n   {repr(self._preset)}"
        return s

    @property
    def categories(self):
        return self.coco.dataset["categories"]

    @property
    def category2name(self):
        return {cat["id"]: cat["name"] for cat in self.categories}

    @property
    def category2label(self):
        return self._category2label

    @property
    def label2category(self):
        return self._label2category


def convert_coco_poly_to_mask(segmentations, height, width):
    masks = []
    for polygons in segmentations:
        rles = coco_mask.frPyObjects(polygons, height, width)
        mask = coco_mask.decode(rles)
        if len(mask.shape) < 3:
            mask = mask[..., None]
        mask = torch.as_tensor(mask, dtype=torch.uint8)
        mask = mask.any(dim=2)
        masks.append(mask)
    if masks:
        masks = torch.stack(masks, dim=0)
    else:
        masks = torch.zeros((0, height, width), dtype=torch.uint8)
    return masks


class ConvertCocoPolysToMask(object):
    def __init__(self, return_masks=False):
        self.return_masks = return_masks

    def __call__(self, image: Image.Image, target, **kwargs):
        """Convert COCO annotations to D-FINE targets.

        This version adds extra safety filtering for RSDA + RSDDs style data:
        masks converted to boxes can produce very thin, near-full-image, or
        otherwise unstable boxes. Those boxes are filtered at load time so they
        cannot enter augmentation / matching and trigger NaN box regression.
        """
        w, h = image.size

        image_id = target["image_id"]
        image_id = torch.tensor([image_id])

        image_path = target["image_path"]
        anno = target["annotations"]
        anno = [obj for obj in anno if "iscrowd" not in obj or obj["iscrowd"] == 0]

        boxes = [obj["bbox"] for obj in anno]
        boxes = torch.as_tensor(boxes, dtype=torch.float32).reshape(-1, 4)

        # Filter invalid raw COCO xywh boxes before xyxy conversion.
        if boxes.numel() > 0:
            finite_keep = torch.isfinite(boxes).all(dim=1)
            wh_keep = (boxes[:, 2] > 0) & (boxes[:, 3] > 0)
            keep_raw = finite_keep & wh_keep
            boxes = boxes[keep_raw]
            anno = [a for a, k in zip(anno, keep_raw.tolist()) if k]

        # COCO bbox: [x, y, width, height] -> [x1, y1, x2, y2]
        if boxes.numel() > 0:
            boxes[:, 2:] += boxes[:, :2]
            boxes[:, 0::2].clamp_(min=0, max=w)
            boxes[:, 1::2].clamp_(min=0, max=h)

            bw = boxes[:, 2] - boxes[:, 0]
            bh = boxes[:, 3] - boxes[:, 1]
            area = bw * bh
            img_area = float(max(w * h, 1))
            aspect = torch.maximum(
                bw / bh.clamp(min=1e-6),
                bh / bw.clamp(min=1e-6),
            )
            area_ratio = area / img_area

            # Conservative defaults for RSDA + RSDDs compatibility.
            min_box_size = 4.0
            min_area = 16.0
            max_aspect_ratio = 10.0
            max_area_ratio = 0.70

            stable_keep = (
                torch.isfinite(boxes).all(dim=1)
                & (bw >= min_box_size)
                & (bh >= min_box_size)
                & (area >= min_area)
                & (aspect <= max_aspect_ratio)
                & (area_ratio <= max_area_ratio)
            )

            boxes = boxes[stable_keep]
            anno = [a for a, k in zip(anno, stable_keep.tolist()) if k]
        else:
            boxes = boxes.reshape(0, 4)

        category2label = kwargs.get("category2label", None)
        if category2label is not None:
            labels = [category2label[obj["category_id"]] for obj in anno]
        else:
            labels = [obj["category_id"] for obj in anno]
        labels = torch.tensor(labels, dtype=torch.int64)

        if self.return_masks:
            segmentations = [obj["segmentation"] for obj in anno]
            masks = convert_coco_poly_to_mask(segmentations, h, w)

        keypoints = None
        if anno and "keypoints" in anno[0]:
            keypoints = [obj["keypoints"] for obj in anno]
            keypoints = torch.as_tensor(keypoints, dtype=torch.float32)
            num_keypoints = keypoints.shape[0]
            if num_keypoints:
                keypoints = keypoints.view(num_keypoints, -1, 3)

        if boxes.numel() > 0:
            keep = (boxes[:, 3] > boxes[:, 1]) & (boxes[:, 2] > boxes[:, 0])
        else:
            keep = torch.zeros((0,), dtype=torch.bool)

        boxes = boxes[keep]
        labels = labels[keep]
        if self.return_masks:
            masks = masks[keep]
        if keypoints is not None:
            keypoints = keypoints[keep]

        target = {}
        target["boxes"] = boxes
        target["labels"] = labels
        if self.return_masks:
            target["masks"] = masks
        target["image_id"] = image_id
        target["image_path"] = image_path
        if keypoints is not None:
            target["keypoints"] = keypoints

        area = torch.tensor([obj.get("area", 0.0) for obj in anno], dtype=torch.float32)
        iscrowd = torch.tensor(
            [obj["iscrowd"] if "iscrowd" in obj else 0 for obj in anno],
            dtype=torch.int64,
        )
        target["area"] = area[keep]
        target["iscrowd"] = iscrowd[keep]
        target["orig_size"] = torch.as_tensor([int(w), int(h)])

        return image, target



# Keep original MS COCO mappings for compatibility with any imports elsewhere.
# They are no longer used by CocoDetection.load_item for custom datasets.
mscoco_category2name = {
    1: "person", 2: "bicycle", 3: "car", 4: "motorcycle", 5: "airplane",
    6: "bus", 7: "train", 8: "truck", 9: "boat", 10: "traffic light",
    11: "fire hydrant", 13: "stop sign", 14: "parking meter", 15: "bench",
    16: "bird", 17: "cat", 18: "dog", 19: "horse", 20: "sheep", 21: "cow",
    22: "elephant", 23: "bear", 24: "zebra", 25: "giraffe", 27: "backpack",
    28: "umbrella", 31: "handbag", 32: "tie", 33: "suitcase", 34: "frisbee",
    35: "skis", 36: "snowboard", 37: "sports ball", 38: "kite",
    39: "baseball bat", 40: "baseball glove", 41: "skateboard", 42: "surfboard",
    43: "tennis racket", 44: "bottle", 46: "wine glass", 47: "cup", 48: "fork",
    49: "knife", 50: "spoon", 51: "bowl", 52: "banana", 53: "apple",
    54: "sandwich", 55: "orange", 56: "broccoli", 57: "carrot", 58: "hot dog",
    59: "pizza", 60: "donut", 61: "cake", 62: "chair", 63: "couch",
    64: "potted plant", 65: "bed", 67: "dining table", 70: "toilet",
    72: "tv", 73: "laptop", 74: "mouse", 75: "remote", 76: "keyboard",
    77: "cell phone", 78: "microwave", 79: "oven", 80: "toaster", 81: "sink",
    82: "refrigerator", 84: "book", 85: "clock", 86: "vase", 87: "scissors",
    88: "teddy bear", 89: "hair drier", 90: "toothbrush",
}

mscoco_category2label = {k: i for i, k in enumerate(mscoco_category2name.keys())}
mscoco_label2category = {v: k for k, v in mscoco_category2label.items()}
