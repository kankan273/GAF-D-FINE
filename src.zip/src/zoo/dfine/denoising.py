"""Copyright(c) 2023 lyuwenyu. All Rights Reserved.
Modifications Copyright (c) 2024 The D-FINE Authors. All Rights Reserved.
"""

import torch

from .box_ops import box_cxcywh_to_xyxy, box_xyxy_to_cxcywh
from .utils import inverse_sigmoid


def get_contrastive_denoising_training_group(
    targets,
    num_classes,
    num_queries,
    class_embed,
    num_denoising=100,
    label_noise_ratio=0.5,
    box_noise_scale=1.0,
    # ===== SSA-DN: Scale-Shape Adaptive Denoising Query =====
    # The following options only affect denoising queries during training.
    # They do not change the inference graph or post-processing.
    use_scale_shape_adaptive_dn=False,
    ssadn_area_min=0.0001,
    ssadn_area_max=0.50,
    ssadn_noise_min=0.20,
    ssadn_noise_max=0.80,
    ssadn_aspect_thr=3.0,
    ssadn_short_side_factor=0.50,
    ssadn_epoch_decay=False,
    ssadn_decay_min=0.50,
    ssadn_epoch=0,
    ssadn_max_epoch=60,
):
    """cnd"""
    if num_denoising <= 0:
        return None, None, None, None

    num_gts = [len(t["labels"]) for t in targets]
    device = targets[0]["labels"].device

    max_gt_num = max(num_gts)
    if max_gt_num == 0:
        dn_meta = {"dn_positive_idx": None, "dn_num_group": 0, "dn_num_split": [0, num_queries]}
        return None, None, None, dn_meta

    num_group = num_denoising // max_gt_num
    num_group = 1 if num_group == 0 else num_group
    # pad gt to max_num of a batch
    bs = len(num_gts)

    input_query_class = torch.full([bs, max_gt_num], num_classes, dtype=torch.int32, device=device)
    input_query_bbox = torch.zeros([bs, max_gt_num, 4], device=device)
    pad_gt_mask = torch.zeros([bs, max_gt_num], dtype=torch.bool, device=device)

    for i in range(bs):
        num_gt = num_gts[i]
        if num_gt > 0:
            input_query_class[i, :num_gt] = targets[i]["labels"]
            input_query_bbox[i, :num_gt] = targets[i]["boxes"]
            pad_gt_mask[i, :num_gt] = 1
    # each group has positive and negative queries.
    input_query_class = input_query_class.tile([1, 2 * num_group])
    input_query_bbox = input_query_bbox.tile([1, 2 * num_group, 1])
    pad_gt_mask = pad_gt_mask.tile([1, 2 * num_group])
    # positive and negative mask
    negative_gt_mask = torch.zeros([bs, max_gt_num * 2, 1], device=device)
    negative_gt_mask[:, max_gt_num:] = 1
    negative_gt_mask = negative_gt_mask.tile([1, num_group, 1])
    positive_gt_mask = 1 - negative_gt_mask
    # contrastive denoising training positive index
    positive_gt_mask = positive_gt_mask.squeeze(-1) * pad_gt_mask
    dn_positive_idx = torch.nonzero(positive_gt_mask)[:, 1]
    dn_positive_idx = torch.split(dn_positive_idx, [n * num_group for n in num_gts])
    # total denoising queries
    num_denoising = int(max_gt_num * 2 * num_group)

    if label_noise_ratio > 0:
        mask = torch.rand_like(input_query_class, dtype=torch.float) < (label_noise_ratio * 0.5)
        # randomly put a new one here
        new_label = torch.randint_like(mask, 0, num_classes, dtype=input_query_class.dtype)
        input_query_class = torch.where(mask & pad_gt_mask, new_label, input_query_class)

    if box_noise_scale > 0:
        known_bbox = box_cxcywh_to_xyxy(input_query_bbox)

        wh = input_query_bbox[..., 2:].clamp(min=1e-6)

        if use_scale_shape_adaptive_dn:
            # ----- 1) Scale-adaptive noise -----
            # Small defects are sensitive to large noise, while large defects can
            # tolerate stronger perturbation. Area is normalized because boxes are
            # already in cxcywh format within [0, 1].
            area = (wh[..., 0] * wh[..., 1]).clamp(min=0.0)
            area_min = float(ssadn_area_min)
            area_max = max(float(ssadn_area_max), area_min + 1e-6)
            scale_ratio = ((area - area_min) / (area_max - area_min)).clamp(0.0, 1.0)

            noise_min = float(ssadn_noise_min)
            noise_max = max(float(ssadn_noise_max), noise_min + 1e-6)
            adaptive_scale = noise_min + scale_ratio * (noise_max - noise_min)

            # Optional curriculum decay: strong denoising early, weaker perturbation
            # later for high-IoU localization. It requires det_engine.py to call
            # model.set_epoch(epoch, epochs). If not called, epoch=0 and decay=1.
            if ssadn_epoch_decay:
                max_epoch = max(float(ssadn_max_epoch), 1.0)
                progress = min(max(float(ssadn_epoch) / max_epoch, 0.0), 1.0)
                decay_min = min(max(float(ssadn_decay_min), 0.0), 1.0)
                decay = 1.0 - progress * (1.0 - decay_min)
                adaptive_scale = adaptive_scale * decay

            adaptive_scale = adaptive_scale * float(box_noise_scale)

            # ----- 2) Shape-adaptive anisotropic noise -----
            # Rail defects often have long-strip shapes. Perturb more along the long
            # side, and suppress perturbation along the short side to avoid destroying
            # narrow defects.
            w, h = wh[..., 0], wh[..., 1]
            aspect_thr = max(float(ssadn_aspect_thr), 1.0)
            short_factor = min(max(float(ssadn_short_side_factor), 0.0), 1.0)

            x_factor = torch.ones_like(w)
            y_factor = torch.ones_like(h)
            horizontal = w > h * aspect_thr
            vertical = h > w * aspect_thr
            y_factor = torch.where(horizontal, torch.full_like(y_factor, short_factor), y_factor)
            x_factor = torch.where(vertical, torch.full_like(x_factor, short_factor), x_factor)

            shape_factor = torch.stack([x_factor, y_factor, x_factor, y_factor], dim=-1)
            base_diff = torch.tile(wh * 0.5, [1, 1, 2])
            diff = base_diff * adaptive_scale.unsqueeze(-1) * shape_factor
        else:
            diff = torch.tile(wh * 0.5, [1, 1, 2]) * box_noise_scale

        rand_sign = torch.randint_like(input_query_bbox, 0, 2) * 2.0 - 1.0
        rand_part = torch.rand_like(input_query_bbox)
        rand_part = (rand_part + 1.0) * negative_gt_mask + rand_part * (1 - negative_gt_mask)
        # shrink_mask = torch.zeros_like(rand_sign)
        # shrink_mask[:, :, :2] = (rand_sign[:, :, :2] == 1)  # rand_sign == 1 → (x1, y1) ↘ →  smaller bbox
        # shrink_mask[:, :, 2:] = (rand_sign[:, :, 2:] == -1)  # rand_sign == -1 →  (x2, y2) ↖ →  smaller bbox
        # mask = rand_part > (upper_bound / (upper_bound+1))
        # # this is to make sure the dn bbox can be reversed to the original bbox by dfine head.
        # rand_sign = torch.where((shrink_mask * (1 - negative_gt_mask) * mask).bool(), \
        #                         rand_sign * upper_bound / (upper_bound+1) / rand_part, rand_sign)
        known_bbox += rand_sign * rand_part * diff
        known_bbox = torch.clip(known_bbox, min=0.0, max=1.0)
        input_query_bbox = box_xyxy_to_cxcywh(known_bbox)
        input_query_bbox[input_query_bbox < 0] *= -1
        input_query_bbox_unact = inverse_sigmoid(input_query_bbox)

    input_query_logits = class_embed(input_query_class)

    tgt_size = num_denoising + num_queries
    attn_mask = torch.full([tgt_size, tgt_size], False, dtype=torch.bool, device=device)
    # match query cannot see the reconstruction
    attn_mask[num_denoising:, :num_denoising] = True

    # reconstruct cannot see each other
    for i in range(num_group):
        if i == 0:
            attn_mask[
                max_gt_num * 2 * i : max_gt_num * 2 * (i + 1),
                max_gt_num * 2 * (i + 1) : num_denoising,
            ] = True
        if i == num_group - 1:
            attn_mask[max_gt_num * 2 * i : max_gt_num * 2 * (i + 1), : max_gt_num * i * 2] = True
        else:
            attn_mask[
                max_gt_num * 2 * i : max_gt_num * 2 * (i + 1),
                max_gt_num * 2 * (i + 1) : num_denoising,
            ] = True
            attn_mask[max_gt_num * 2 * i : max_gt_num * 2 * (i + 1), : max_gt_num * 2 * i] = True

    dn_meta = {
        "dn_positive_idx": dn_positive_idx,
        "dn_num_group": num_group,
        "dn_num_split": [num_denoising, num_queries],
    }

    # print(input_query_class.shape) # torch.Size([4, 196, 256])
    # print(input_query_bbox.shape) # torch.Size([4, 196, 4])
    # print(attn_mask.shape) # torch.Size([496, 496])

    return input_query_logits, input_query_bbox_unact, attn_mask, dn_meta
