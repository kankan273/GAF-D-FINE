"""
D-FINE: Redefine Regression Task of DETRs as Fine-grained Distribution Refinement
Copyright (c) 2024 The D-FINE Authors. All Rights Reserved.
---------------------------------------------------------------------------------
Modified from RT-DETR (https://github.com/lyuwenyu/RT-DETR)
Copyright (c) 2023 lyuwenyu. All Rights Reserved.
"""

import copy

import torch
import torch.distributed
import torch.nn as nn
import torch.nn.functional as F
import torchvision

from ...core import register
from ...misc.dist_utils import get_world_size, is_dist_available_and_initialized
from .box_ops import box_cxcywh_to_xyxy, box_iou, generalized_box_iou
from .dfine_utils import bbox2distance


@register()
class DFINECriterion(nn.Module):
    """This class computes the loss for D-FINE."""

    __share__ = [
        "num_classes",
    ]
    __inject__ = [
        "matcher",
    ]

    def __init__(
        self,
        matcher,
        weight_dict,
        losses,
        alpha=0.2,
        gamma=2.0,
        num_classes=80,
        reg_max=32,
        boxes_weight_format=None,
        share_matched_indices=False,
        use_consistency=False,
        consistency_weight=0.05,
        consistency_last_k=2,
        consistency_margin=0.0,
        use_scale_aware_calibration=False,
        use_scale_guided_regularization=False,
        sadc_temp_min=0.90,
        sadc_temp_max=1.10,
        sgr_area_min=0.0001,
        sgr_area_max=0.50,
        sgr_start_epoch=0,
        sgr_warmup_epochs=0,
        sgr_min_iou=0.0,
        sgr_min_area=0.0,
        **kwargs,
    ):
        super().__init__()
        self.num_classes = num_classes
        self.matcher = matcher
        self.weight_dict = dict(weight_dict)
        self.losses = list(losses)
        self.boxes_weight_format = boxes_weight_format
        self.share_matched_indices = share_matched_indices
        self.alpha = alpha
        self.gamma = gamma
        self.reg_max = reg_max
        self.fgl_targets, self.fgl_targets_dn = None, None
        self.own_targets, self.own_targets_dn = None, None
        self.num_pos, self.num_neg = None, None

        # ===== 跨层一致性配置 =====
        self.use_consistency = use_consistency
        self.consistency_weight = consistency_weight
        self.consistency_last_k = consistency_last_k
        self.consistency_margin = consistency_margin

        # 保存但不在 criterion 中直接启用，防止 YAML 参数和代码签名不兼容。
        self.use_scale_aware_calibration = use_scale_aware_calibration
        self.use_scale_guided_regularization = use_scale_guided_regularization
        self.sadc_temp_min = sadc_temp_min
        self.sadc_temp_max = sadc_temp_max
        self.sgr_area_min = sgr_area_min
        self.sgr_area_max = sgr_area_max
        self.sgr_start_epoch = int(sgr_start_epoch)
        self.sgr_warmup_epochs = int(sgr_warmup_epochs)
        self.sgr_min_iou = float(sgr_min_iou)
        self.sgr_min_area = float(sgr_min_area)
        self.extra_cfg = kwargs
        if not self.use_scale_guided_regularization:
            self.losses = [x for x in self.losses if x != "sgr"]

        if self.use_consistency and "consistency" not in self.losses:
            self.losses.append("consistency")
        if self.use_consistency and "loss_consistency" not in self.weight_dict:
            self.weight_dict["loss_consistency"] = consistency_weight

    def loss_labels_focal(self, outputs, targets, indices, num_boxes):
        assert "pred_logits" in outputs
        src_logits = outputs["pred_logits"]
        idx = self._get_src_permutation_idx(indices)
        target_classes_o = torch.cat([t["labels"][J] for t, (_, J) in zip(targets, indices)])
        target_classes = torch.full(
            src_logits.shape[:2], self.num_classes, dtype=torch.int64, device=src_logits.device
        )
        target_classes[idx] = target_classes_o
        target = F.one_hot(target_classes, num_classes=self.num_classes + 1)[..., :-1]
        loss = torchvision.ops.sigmoid_focal_loss(
            src_logits, target, self.alpha, self.gamma, reduction="none"
        )
        loss = loss.mean(1).sum() * src_logits.shape[1] / num_boxes

        return {"loss_focal": loss}

    def loss_labels_vfl(self, outputs, targets, indices, num_boxes, values=None):
        assert "pred_boxes" in outputs
        idx = self._get_src_permutation_idx(indices)
        if values is None:
            src_boxes = outputs["pred_boxes"][idx]
            target_boxes = torch.cat([t["boxes"][i] for t, (_, i) in zip(targets, indices)], dim=0)
            ious, _ = box_iou(box_cxcywh_to_xyxy(src_boxes), box_cxcywh_to_xyxy(target_boxes))
            ious = torch.diag(ious).detach()
        else:
            ious = values

        src_logits = outputs["pred_logits"]
        target_classes_o = torch.cat([t["labels"][J] for t, (_, J) in zip(targets, indices)])
        target_classes = torch.full(
            src_logits.shape[:2], self.num_classes, dtype=torch.int64, device=src_logits.device
        )
        target_classes[idx] = target_classes_o
        target = F.one_hot(target_classes, num_classes=self.num_classes + 1)[..., :-1]

        target_score_o = torch.zeros_like(target_classes, dtype=src_logits.dtype)
        target_score_o[idx] = ious.to(target_score_o.dtype)
        target_score = target_score_o.unsqueeze(-1) * target

        pred_score = F.sigmoid(src_logits).detach()
        weight = self.alpha * pred_score.pow(self.gamma) * (1 - target) + target_score

        loss = F.binary_cross_entropy_with_logits(
            src_logits, target_score, weight=weight, reduction="none"
        )
        loss = loss.mean(1).sum() * src_logits.shape[1] / num_boxes
        return {"loss_vfl": loss}

    def loss_boxes(self, outputs, targets, indices, num_boxes, boxes_weight=None):
        """Compute the losses related to the bounding boxes, the L1 regression loss and the GIoU loss"""
        assert "pred_boxes" in outputs
        idx = self._get_src_permutation_idx(indices)
        src_boxes = outputs["pred_boxes"][idx]
        target_boxes = torch.cat([t["boxes"][i] for t, (_, i) in zip(targets, indices)], dim=0)
        losses = {}
        loss_bbox = F.l1_loss(src_boxes, target_boxes, reduction="none")
        losses["loss_bbox"] = loss_bbox.sum() / num_boxes

        loss_giou = 1 - torch.diag(
            generalized_box_iou(box_cxcywh_to_xyxy(src_boxes), box_cxcywh_to_xyxy(target_boxes))
        )
        loss_giou = loss_giou if boxes_weight is None else loss_giou * boxes_weight
        losses["loss_giou"] = loss_giou.sum() / num_boxes

        return losses

    def loss_local(self, outputs, targets, indices, num_boxes, T=5):
        """Compute Fine-Grained Localization (FGL) Loss and Decoupled Distillation Focal (DDF) Loss."""
        losses = {}
        if "pred_corners" in outputs:
            idx = self._get_src_permutation_idx(indices)
            target_boxes = torch.cat([t["boxes"][i] for t, (_, i) in zip(targets, indices)], dim=0)
            pred_corners = outputs["pred_corners"][idx].reshape(-1, (self.reg_max + 1))
            ref_points = outputs["ref_points"][idx].detach()

            # ========== 没有匹配正样本时，local loss 直接置 0 ==========
            if pred_corners.numel() == 0:
                zero_loss = outputs["pred_corners"].sum() * 0.0
                losses["loss_fgl"] = zero_loss
                if "teacher_corners" in outputs:
                    losses["loss_ddf"] = zero_loss
                return losses

            with torch.no_grad():
                if self.fgl_targets_dn is None and "is_dn" in outputs:
                    self.fgl_targets_dn = bbox2distance(
                        ref_points,
                        box_cxcywh_to_xyxy(target_boxes),
                        self.reg_max,
                        outputs["reg_scale"],
                        outputs["up"],
                    )

                if self.fgl_targets is None and "is_dn" not in outputs:
                    self.fgl_targets = bbox2distance(
                        ref_points,
                        box_cxcywh_to_xyxy(target_boxes),
                        self.reg_max,
                        outputs["reg_scale"],
                        outputs["up"],
                    )

                target_corners, weight_right, weight_left = (
                    self.fgl_targets_dn if "is_dn" in outputs else self.fgl_targets
                )

            ious = torch.diag(
                box_iou(
                    box_cxcywh_to_xyxy(outputs["pred_boxes"][idx]),
                    box_cxcywh_to_xyxy(target_boxes),
                )[0]
            )
            weight_targets = ious.unsqueeze(-1).repeat(1, 1, 4).reshape(-1).detach()

            losses["loss_fgl"] = self.unimodal_distribution_focal_loss(
                pred_corners,
                target_corners,
                weight_right,
                weight_left,
                weight_targets,
                avg_factor=num_boxes,
            )

            # DDF loss (optional, can be disabled by setting weight 0)
            if "teacher_corners" in outputs:
                pred_corners_all = outputs["pred_corners"].reshape(-1, (self.reg_max + 1))
                target_corners_all = outputs["teacher_corners"].reshape(-1, (self.reg_max + 1))

                if torch.equal(pred_corners_all, target_corners_all):
                    losses["loss_ddf"] = pred_corners_all.sum() * 0
                else:
                    weight_targets_local = outputs["teacher_logits"].sigmoid().max(dim=-1)[0]
                    mask = torch.zeros_like(weight_targets_local, dtype=torch.bool)
                    mask[idx] = True
                    mask = mask.unsqueeze(-1).repeat(1, 1, 4).reshape(-1)

                    weight_targets_local[idx] = ious.reshape_as(weight_targets_local[idx]).to(
                        weight_targets_local.dtype
                    )
                    weight_targets_local = (
                        weight_targets_local.unsqueeze(-1).repeat(1, 1, 4).reshape(-1).detach()
                    )

                    loss_match_local = (
                        F.kl_div(
                            F.log_softmax(pred_corners_all, dim=-1),
                            F.softmax(target_corners_all.detach(), dim=-1),
                            reduction="none",
                        ).sum(-1)
                    )

                    losses["loss_ddf"] = (loss_match_local * weight_targets_local).sum() / num_boxes

        return losses


    def _compute_entropy(self, logits):
        probs = F.softmax(logits, dim=-1)
        return -(probs * torch.log(probs.clamp_min(1e-8))).sum(dim=-1)

    def _compute_layer_consistency(self, pred_distributions, indices):
        if len(pred_distributions) < 2:
            device = pred_distributions[0].device if len(pred_distributions) > 0 else "cpu"
            return torch.tensor(0.0, device=device)

        if self.consistency_last_k is not None and self.consistency_last_k > 1:
            pred_distributions = pred_distributions[-self.consistency_last_k:]

        total_loss = 0.0
        num_pairs = 0

        for i in range(len(pred_distributions) - 1):
            shallow_logits = pred_distributions[i]
            deep_logits = pred_distributions[i + 1]

            layer_losses = []
            for batch_idx, (src_idx, _) in enumerate(indices):
                if len(src_idx) == 0:
                    continue

                shallow_matched = shallow_logits[batch_idx, src_idx]  # [Npos, 4, K]
                deep_matched = deep_logits[batch_idx, src_idx]

                shallow_e = self._compute_entropy(shallow_matched)
                deep_e = self._compute_entropy(deep_matched)

                pair_loss = F.relu(deep_e - shallow_e + self.consistency_margin)
                layer_losses.append(pair_loss.mean())

            if len(layer_losses) == 0:
                continue
            total_loss = total_loss + torch.stack(layer_losses).mean()
            num_pairs += 1

        if num_pairs == 0:
            return pred_distributions[-1].sum() * 0.0
        return total_loss / num_pairs

    def loss_consistency(self, outputs, targets, indices, num_boxes, **kwargs):
        device = outputs["pred_boxes"].device
        if not self.use_consistency:
            return {"loss_consistency": torch.tensor(0.0, device=device)}
        if "pred_corners" not in outputs:
            return {"loss_consistency": torch.tensor(0.0, device=device)}
        if "aux_outputs" not in outputs or len(outputs["aux_outputs"]) == 0:
            return {"loss_consistency": torch.tensor(0.0, device=device)}

        B, N = outputs["pred_corners"].shape[:2]
        K = self.reg_max + 1

        pred_distributions = []
        for aux_out in outputs["aux_outputs"]:
            if "pred_corners" in aux_out:
                pred_distributions.append(aux_out["pred_corners"].reshape(B, N, 4, K))
        pred_distributions.append(outputs["pred_corners"].reshape(B, N, 4, K))

        consistency_loss = self._compute_layer_consistency(pred_distributions, indices)
        return {"loss_consistency": consistency_loss}
    def _get_src_permutation_idx(self, indices):
        batch_idx = torch.cat([torch.full_like(src, i) for i, (src, _) in enumerate(indices)])
        src_idx = torch.cat([src for (src, _) in indices])
        return batch_idx, src_idx

    def _get_tgt_permutation_idx(self, indices):
        batch_idx = torch.cat([torch.full_like(tgt, i) for i, (_, tgt) in enumerate(indices)])
        tgt_idx = torch.cat([tgt for (_, tgt) in indices])
        return batch_idx, tgt_idx

    def _get_go_indices(self, indices, indices_aux_list):
        results = []
        for indices_aux in indices_aux_list:
            indices = [
                (torch.cat([idx1[0], idx2[0]]), torch.cat([idx1[1], idx2[1]]))
                for idx1, idx2 in zip(indices.copy(), indices_aux.copy())
            ]

        for ind in [torch.cat([idx[0][:, None], idx[1][:, None]], 1) for idx in indices]:
            unique, counts = torch.unique(ind, return_counts=True, dim=0)
            count_sort_indices = torch.argsort(counts, descending=True)
            unique_sorted = unique[count_sort_indices]
            column_to_row = {}
            for idx in unique_sorted:
                row_idx, col_idx = idx[0].item(), idx[1].item()
                if row_idx not in column_to_row:
                    column_to_row[row_idx] = col_idx
            final_rows = torch.tensor(list(column_to_row.keys()), device=ind.device)
            final_cols = torch.tensor(list(column_to_row.values()), device=ind.device)
            results.append((final_rows.long(), final_cols.long()))
        return results

    def _clear_cache(self):
        self.fgl_targets, self.fgl_targets_dn = None, None
        self.own_targets, self.own_targets_dn = None, None
        self.num_pos, self.num_neg = None, None

    def _get_sgr_schedule_weight(self, outputs, **kwargs):
        ref = outputs.get("pred_boxes", None)
        if ref is None:
            ref = next(iter(outputs.values()))

        epoch = kwargs.get("epoch", None)
        if epoch is None:
            return ref.new_tensor(1.0)

        try:
            epoch_value = int(epoch)
        except Exception:
            return ref.new_tensor(1.0)

        if epoch_value < self.sgr_start_epoch:
            return ref.new_tensor(0.0)

        if self.sgr_warmup_epochs <= 0:
            return ref.new_tensor(1.0)

        progress = (epoch_value - self.sgr_start_epoch + 1) / max(float(self.sgr_warmup_epochs), 1.0)
        progress = max(0.0, min(1.0, progress))
        return ref.new_tensor(progress)

    def loss_sgr(self, outputs, targets, indices, num_boxes, **kwargs):
        if not self.use_scale_guided_regularization:
            ref = outputs.get("pred_boxes", None)
            if ref is None:
                ref = next(iter(outputs.values()))
            return {"loss_sgr": ref.sum() * 0.0}

        if "pred_boxes" not in outputs:
            ref = next(iter(outputs.values()))
            return {"loss_sgr": ref.sum() * 0.0}

        # Delayed schedule: early epochs return zero so SGR does not disturb coarse learning.
        schedule_weight = self._get_sgr_schedule_weight(outputs, **kwargs)
        if float(schedule_weight.detach().item()) <= 0.0:
            return {"loss_sgr": outputs["pred_boxes"].sum() * 0.0}

        idx = self._get_src_permutation_idx(indices)

        # 没有匹配正样本时，返回可反传的 0
        if len(idx[0]) == 0:
            return {"loss_sgr": outputs["pred_boxes"].sum() * 0.0}

        src_boxes = outputs["pred_boxes"][idx]
        target_boxes = torch.cat(
            [t["boxes"][j] for t, (_, j) in zip(targets, indices)],
            dim=0,
        )

        if src_boxes.numel() == 0 or target_boxes.numel() == 0:
            return {"loss_sgr": outputs["pred_boxes"].sum() * 0.0}

        # 防止异常值进入正则项
        src_boxes = torch.nan_to_num(
            src_boxes, nan=0.5, posinf=1.0, neginf=0.0
        ).clamp(0.0, 1.0)
        target_boxes = torch.nan_to_num(
            target_boxes, nan=0.5, posinf=1.0, neginf=0.0
        ).clamp(0.0, 1.0)

        # target_boxes 为 cxcywh，面积为 w*h
        tgt_w = target_boxes[:, 2].clamp(min=1e-6)
        tgt_h = target_boxes[:, 3].clamp(min=1e-6)
        tgt_area = (tgt_w * tgt_h).clamp(min=0.0, max=1.0)

        area_min = float(self.sgr_area_min)
        area_max = float(self.sgr_area_max)
        area_scale = (tgt_area - area_min) / max(area_max - area_min, 1e-6)
        area_scale = area_scale.clamp(0.0, 1.0)

        temp_min = float(self.sadc_temp_min)
        temp_max = float(self.sadc_temp_max)
        scale_weight = temp_min + (temp_max - temp_min) * area_scale
        scale_weight = scale_weight.detach()

        # 每个匹配框的 L1 误差
        bbox_l1 = torch.abs(src_boxes - target_boxes).mean(dim=-1)

        # IoU gate：只强约束质量较高的匹配框，避免早期/低质量匹配被 SGR 过度拉扯。
        # 这能缓解 SGR 让模型过度保守、Recall 下降的问题。
        with torch.no_grad():
            ious = torch.diag(
                box_iou(
                    box_cxcywh_to_xyxy(src_boxes),
                    box_cxcywh_to_xyxy(target_boxes),
                )[0]
            ).clamp(0.0, 1.0)
            iou_weight = ious.detach()

        valid_mask = (iou_weight >= self.sgr_min_iou) & (tgt_area >= self.sgr_min_area)
        if not valid_mask.any():
            return {"loss_sgr": outputs["pred_boxes"].sum() * 0.0}

        loss_sgr = (
            bbox_l1[valid_mask]
            * scale_weight[valid_mask]
            * iou_weight[valid_mask]
        ).sum() / max(float(num_boxes), 1.0)

        loss_sgr = loss_sgr * schedule_weight

        return {"loss_sgr": loss_sgr}

    def get_loss(self, loss, outputs, targets, indices, num_boxes, **kwargs):
        loss_map = {
            "boxes": self.loss_boxes,
            "focal": self.loss_labels_focal,
            "vfl": self.loss_labels_vfl,
            "local": self.loss_local,
            "consistency": self.loss_consistency,
            "sgr": self.loss_sgr,
        }
        assert loss in loss_map, f"do you really want to compute {loss} loss?"
        return loss_map[loss](outputs, targets, indices, num_boxes, **kwargs)

    def forward(self, outputs, targets, **kwargs):
        outputs_without_aux = {k: v for k, v in outputs.items() if "aux" not in k}
        indices = self.matcher(outputs_without_aux, targets)["indices"]
        self._clear_cache()

        if "aux_outputs" in outputs:
            indices_aux_list, cached_indices, cached_indices_enc = [], [], []
            aux_match_outputs = list(outputs["aux_outputs"])
            if "pre_outputs" in outputs:
                aux_match_outputs.append(outputs["pre_outputs"])

            for aux_outputs in aux_match_outputs:
                indices_aux = self.matcher(aux_outputs, targets)["indices"]
                cached_indices.append(indices_aux)
                indices_aux_list.append(indices_aux)
            for aux_outputs in outputs["enc_aux_outputs"]:
                indices_enc = self.matcher(aux_outputs, targets)["indices"]
                cached_indices_enc.append(indices_enc)
                indices_aux_list.append(indices_enc)
            indices_go = self._get_go_indices(indices, indices_aux_list)

            num_boxes_go = sum(len(x[0]) for x in indices_go)
            num_boxes_go = torch.as_tensor(
                [num_boxes_go], dtype=torch.float, device=next(iter(outputs.values())).device
            )
            if is_dist_available_and_initialized():
                torch.distributed.all_reduce(num_boxes_go)
            num_boxes_go = torch.clamp(num_boxes_go / get_world_size(), min=1).item()
        else:
            assert "aux_outputs" in outputs, ""

        num_boxes = sum(len(t["labels"]) for t in targets)
        num_boxes = torch.as_tensor(
            [num_boxes], dtype=torch.float, device=next(iter(outputs.values())).device
        )
        if is_dist_available_and_initialized():
            torch.distributed.all_reduce(num_boxes)
        num_boxes = torch.clamp(num_boxes / get_world_size(), min=1).item()

        losses = {}
        for loss in self.losses:
            indices_in = indices_go if loss in ["boxes", "local", "consistency"] else indices
            num_boxes_in = num_boxes_go if loss in ["boxes", "local", "consistency"] else num_boxes
            meta = self.get_loss_meta_info(loss, outputs, targets, indices_in)
            if loss == "sgr":
                l_dict = self.get_loss(loss, outputs, targets, indices_in, num_boxes_in, **meta, **kwargs)
            else:
                l_dict = self.get_loss(loss, outputs, targets, indices_in, num_boxes_in, **meta)
            l_dict = {k: l_dict[k] * self.weight_dict[k] for k in l_dict if k in self.weight_dict}
            losses.update(l_dict)

        # Aux losses (excluding consistency which is global)
        if "aux_outputs" in outputs:
            for i, aux_outputs in enumerate(outputs["aux_outputs"]):
                aux_outputs["up"], aux_outputs["reg_scale"] = outputs["up"], outputs["reg_scale"]
                for loss in self.losses:
                    # SGR 只作用在最终主输出，避免 aux/pre/enc/dn 多分支重复正则导致 Recall 下降。
                    if loss in ["consistency", "sgr"]:
                        continue
                    indices_in = indices_go if loss in ["boxes", "local"] else cached_indices[i]
                    num_boxes_in = num_boxes_go if loss in ["boxes", "local"] else num_boxes
                    meta = self.get_loss_meta_info(loss, aux_outputs, targets, indices_in)
                    l_dict = self.get_loss(loss, aux_outputs, targets, indices_in, num_boxes_in, **meta)
                    l_dict = {k: l_dict[k] * self.weight_dict[k] for k in l_dict if k in self.weight_dict}
                    l_dict = {k + f"_aux_{i}": v for k, v in l_dict.items()}
                    losses.update(l_dict)

        # Pre output
        if "pre_outputs" in outputs:
            aux_outputs = outputs["pre_outputs"]
            for loss in self.losses:
                # SGR 只作用在最终主输出，避免 pre 分支重复正则。
                if loss in ["consistency", "sgr"]:
                    continue
                indices_in = indices_go if loss in ["boxes", "local"] else cached_indices[-1]
                num_boxes_in = num_boxes_go if loss in ["boxes", "local"] else num_boxes
                meta = self.get_loss_meta_info(loss, aux_outputs, targets, indices_in)
                l_dict = self.get_loss(loss, aux_outputs, targets, indices_in, num_boxes_in, **meta)
                l_dict = {k: l_dict[k] * self.weight_dict[k] for k in l_dict if k in self.weight_dict}
                l_dict = {k + "_pre": v for k, v in l_dict.items()}
                losses.update(l_dict)

        # Encoder aux losses
        if "enc_aux_outputs" in outputs:
            assert "enc_meta" in outputs
            class_agnostic = outputs["enc_meta"]["class_agnostic"]
            if class_agnostic:
                orig_num_classes = self.num_classes
                self.num_classes = 1
                enc_targets = copy.deepcopy(targets)
                for t in enc_targets:
                    t["labels"] = torch.zeros_like(t["labels"])
            else:
                enc_targets = targets

            for i, aux_outputs in enumerate(outputs["enc_aux_outputs"]):
                for loss in self.losses:
                    # SGR 只作用在最终主输出，避免 aux/pre/enc/dn 多分支重复正则导致 Recall 下降。
                    if loss in ["consistency", "sgr"]:
                        continue
                    indices_in = indices_go if loss == "boxes" else cached_indices_enc[i]
                    num_boxes_in = num_boxes_go if loss == "boxes" else num_boxes
                    meta = self.get_loss_meta_info(loss, aux_outputs, enc_targets, indices_in)
                    l_dict = self.get_loss(loss, aux_outputs, enc_targets, indices_in, num_boxes_in, **meta)
                    l_dict = {k: l_dict[k] * self.weight_dict[k] for k in l_dict if k in self.weight_dict}
                    l_dict = {k + f"_enc_{i}": v for k, v in l_dict.items()}
                    losses.update(l_dict)

            if class_agnostic:
                self.num_classes = orig_num_classes

        # DN losses
        if "dn_outputs" in outputs:
            assert "dn_meta" in outputs
            indices_dn = self.get_cdn_matched_indices(outputs["dn_meta"], targets)
            dn_num_boxes = num_boxes * outputs["dn_meta"]["dn_num_group"]
            dn_num_boxes = dn_num_boxes if dn_num_boxes > 0 else 1

            for i, aux_outputs in enumerate(outputs["dn_outputs"]):
                aux_outputs["is_dn"] = True
                aux_outputs["up"], aux_outputs["reg_scale"] = outputs["up"], outputs["reg_scale"]
                for loss in self.losses:
                    # SGR 只作用在最终主输出，避免 aux/pre/enc/dn 多分支重复正则导致 Recall 下降。
                    if loss in ["consistency", "sgr"]:
                        continue
                    meta = self.get_loss_meta_info(loss, aux_outputs, targets, indices_dn)
                    l_dict = self.get_loss(loss, aux_outputs, targets, indices_dn, dn_num_boxes, **meta)
                    l_dict = {k: l_dict[k] * self.weight_dict[k] for k in l_dict if k in self.weight_dict}
                    l_dict = {k + f"_dn_{i}": v for k, v in l_dict.items()}
                    losses.update(l_dict)

            if "dn_pre_outputs" in outputs:
                aux_outputs = outputs["dn_pre_outputs"]
                for loss in self.losses:
                    # SGR 只作用在最终主输出，避免 aux/pre/enc/dn 多分支重复正则导致 Recall 下降。
                    if loss in ["consistency", "sgr"]:
                        continue
                    meta = self.get_loss_meta_info(loss, aux_outputs, targets, indices_dn)
                    l_dict = self.get_loss(loss, aux_outputs, targets, indices_dn, dn_num_boxes, **meta)
                    l_dict = {k: l_dict[k] * self.weight_dict[k] for k in l_dict if k in self.weight_dict}
                    l_dict = {k + "_dn_pre": v for k, v in l_dict.items()}
                    losses.update(l_dict)

        losses = {k: torch.nan_to_num(v, nan=0.0) for k, v in losses.items()}
        return losses

    def get_loss_meta_info(self, loss, outputs, targets, indices):
        if self.boxes_weight_format is None:
            return {}

        src_boxes = outputs["pred_boxes"][self._get_src_permutation_idx(indices)]
        target_boxes = torch.cat([t["boxes"][j] for t, (_, j) in zip(targets, indices)], dim=0)

        if self.boxes_weight_format == "iou":
            iou, _ = box_iou(
                box_cxcywh_to_xyxy(src_boxes.detach()), box_cxcywh_to_xyxy(target_boxes)
            )
            iou = torch.diag(iou)
        elif self.boxes_weight_format == "giou":
            iou = torch.diag(
                generalized_box_iou(
                    box_cxcywh_to_xyxy(src_boxes.detach()), box_cxcywh_to_xyxy(target_boxes)
                )
            )
        else:
            raise AttributeError()

        if loss in ("boxes",):
            meta = {"boxes_weight": iou}
        elif loss in ("vfl",):
            meta = {"values": iou}
        else:
            meta = {}
        return meta

    @staticmethod
    def get_cdn_matched_indices(dn_meta, targets):
        dn_positive_idx, dn_num_group = dn_meta["dn_positive_idx"], dn_meta["dn_num_group"]
        num_gts = [len(t["labels"]) for t in targets]
        device = targets[0]["labels"].device

        dn_match_indices = []
        for i, num_gt in enumerate(num_gts):
            if num_gt > 0:
                gt_idx = torch.arange(num_gt, dtype=torch.int64, device=device)
                gt_idx = gt_idx.tile(dn_num_group)
                assert len(dn_positive_idx[i]) == len(gt_idx)
                dn_match_indices.append((dn_positive_idx[i], gt_idx))
            else:
                dn_match_indices.append(
                    (
                        torch.zeros(0, dtype=torch.int64, device=device),
                        torch.zeros(0, dtype=torch.int64, device=device),
                    )
                )
        return dn_match_indices

    def unimodal_distribution_focal_loss(
        self, pred, label, weight_right, weight_left, weight=None, reduction="sum", avg_factor=None
    ):
1)

