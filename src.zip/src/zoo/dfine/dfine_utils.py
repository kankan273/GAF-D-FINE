"""
D-FINE: Redefine Regression Task of DETRs as Fine-grained Distribution Refinement
Copyright (c) 2024 The D-FINE Authors. All Rights Reserved.
---------------------------------------------------------------------------------
Modified from RT-DETR (https://github.com/lyuwenyu/RT-DETR)
Copyright (c) 2023 lyuwenyu. All Rights Reserved.
---------------------------------------------------------------------------------
Modified for ADM / SAC / SGR stability:
1. Keep original D-FINE non-uniform weighting behavior.
2. Preserve dynamic weighting support for ADM.
3. Add empty-tensor / NaN / Inf guards for stable training.
4. Keep bbox2distance compatible with fixed up and dynamic up.
"""

import torch

from .box_ops import box_xyxy_to_cxcywh


def _as_tensor_like(value, ref_tensor):
    """Convert scalar/tensor value to the dtype/device of ref_tensor."""
    if torch.is_tensor(value):
        return value.to(device=ref_tensor.device, dtype=ref_tensor.dtype)
    return torch.tensor(value, device=ref_tensor.device, dtype=ref_tensor.dtype)


def weighting_function(reg_max, up, reg_scale, deploy=False):
    """
    Original D-FINE non-uniform weighting function.

    Args:
        reg_max (int): Max index of discrete bins.
        up (Tensor): Fixed upper range controller, usually shape [1].
        reg_scale (Tensor or float): Curvature controller.
        deploy (bool): Whether to generate deployment-friendly fixed tensor.

    Returns:
        Tensor:
            Shape [reg_max + 1]
    """
    if reg_max <= 2:
        raise ValueError(f"reg_max must be > 2, got {reg_max}")

    if not torch.is_tensor(up):
        up = torch.tensor([up], dtype=torch.float32)

    reg_scale_abs = torch.abs(_as_tensor_like(reg_scale, up))

    # 防止极端值导致 step/values 出现 NaN/Inf
    up_abs = torch.abs(up[0]).clamp(min=1e-6)
    reg_scale_abs = reg_scale_abs.clamp(min=1e-6)

    if deploy:
        upper_bound1 = (up_abs * reg_scale_abs).item()
        upper_bound2 = (up_abs * reg_scale_abs * 2.0).item()
        step = (upper_bound1 + 1.0) ** (2.0 / (reg_max - 2))

        left_values = [-((step) ** i) + 1.0 for i in range(reg_max // 2 - 1, 0, -1)]
        right_values = [(step) ** i - 1.0 for i in range(1, reg_max // 2)]

        values = [-upper_bound2] + left_values + [0.0] + right_values + [upper_bound2]
        out = torch.tensor(values, dtype=up.dtype, device=up.device)
        return torch.nan_to_num(out, nan=0.0, posinf=upper_bound2, neginf=-upper_bound2)

    upper_bound1 = up_abs * reg_scale_abs
    upper_bound2 = up_abs * reg_scale_abs * 2.0
    step = (upper_bound1 + 1.0) ** (2.0 / (reg_max - 2))

    left_values = [
        (-((step) ** i) + 1.0).reshape(1)
        for i in range(reg_max // 2 - 1, 0, -1)
    ]
    right_values = [
        (((step) ** i) - 1.0).reshape(1)
        for i in range(1, reg_max // 2)
    ]

    values = (
        [(-upper_bound2).reshape(1)]
        + left_values
        + [torch.zeros(1, dtype=up.dtype, device=up.device)]
        + right_values
        + [upper_bound2.reshape(1)]
    )

    out = torch.cat(values, dim=0)
    out = torch.nan_to_num(
        out,
        nan=0.0,
        posinf=float(upper_bound2.detach().max().item()),
        neginf=-float(upper_bound2.detach().max().item()),
    )
    return out


def weighting_function_dynamic(reg_max, up, reg_scale):
    """
    Dynamic non-uniform weighting function for ADM.

    Different query/target can have different effective discretization ranges.

    Args:
        reg_max (int): Max index of discrete bins.
        up (Tensor):
            Dynamic upper range controller.
            Supported shapes:
                [B, Q, 1]  -> will be squeezed to [B, Q, K]
                [N, 1]     -> will be squeezed to [N, K]
                [N]        -> [N, K]
        reg_scale (Tensor or float): Curvature controller.

    Returns:
        Tensor:
            Shape [..., reg_max + 1]
    """
    if reg_max <= 2:
        raise ValueError(f"reg_max must be > 2, got {reg_max}")

    if not torch.is_tensor(up):
        up = torch.tensor([up], dtype=torch.float32)

    # Normalize up shape
    if up.dim() == 0:
        up = up.view(1, 1)
    elif up.dim() == 1:
        up = up.unsqueeze(-1)

    up = torch.nan_to_num(up, nan=0.5, posinf=1.0, neginf=0.0).clamp(min=1e-6)

    reg_scale_abs = torch.abs(_as_tensor_like(reg_scale, up)).clamp(min=1e-6)

    upper_bound1 = torch.abs(up) * reg_scale_abs
    upper_bound2 = torch.abs(up) * reg_scale_abs * 2.0

    step = (upper_bound1 + 1.0) ** (2.0 / (reg_max - 2))

    device = up.device
    dtype = up.dtype

    left_idx = torch.arange(reg_max // 2 - 1, 0, -1, device=device, dtype=dtype)
    right_idx = torch.arange(1, reg_max // 2, device=device, dtype=dtype)

    left_values = -(step ** left_idx) + 1.0          # [..., L]
    center_value = torch.zeros_like(up)              # [..., 1]
    right_values = (step ** right_idx) - 1.0         # [..., R]

    values = torch.cat(
        [
            -upper_bound2,          # [..., 1]
            left_values,            # [..., L]
            center_value,           # [..., 1]
            right_values,           # [..., R]
            upper_bound2,           # [..., 1]
        ],
        dim=-1,                     # [..., 1+L+1+R+1] = [..., K]
    )

    # Remove the extra singleton dimension if up had shape [..., 1]
    if values.dim() >= 3 and values.shape[-2] == 1:
        values = values.squeeze(-2)

    max_abs = torch.nan_to_num(upper_bound2.detach().max(), nan=1.0, posinf=1.0, neginf=1.0)
    values = torch.nan_to_num(values, nan=0.0, posinf=float(max_abs.item()), neginf=-float(max_abs.item()))
    return values


def translate_gt(gt, reg_max, reg_scale, up):
    """
    Original fixed-up target translation.

    Args:
        gt (Tensor): Regression targets.
        reg_max (int): Max index of discrete bins.
        reg_scale (Tensor or float): Curvature controller.
        up (Tensor): Fixed upper range controller.

    Returns:
        indices, weight_right, weight_left
    """
    gt = gt.reshape(-1)

    if gt.numel() == 0:
        return gt, gt, gt

    gt = torch.nan_to_num(gt, nan=0.0, posinf=0.0, neginf=0.0)

    function_values = weighting_function(reg_max, up, reg_scale).to(device=gt.device, dtype=gt.dtype)

    diffs = function_values.unsqueeze(0) - gt.unsqueeze(1)
    mask = diffs <= 0
    closest_left_indices = torch.sum(mask, dim=1) - 1

    indices = closest_left_indices.float()
    weight_right = torch.zeros_like(indices)
    weight_left = torch.zeros_like(indices)

    valid_idx_mask = (indices >= 0) & (indices < reg_max)

    if valid_idx_mask.any():
        valid_indices = indices[valid_idx_mask].long()

        left_values = function_values[valid_indices]
        right_values = function_values[valid_indices + 1]

        left_diffs = torch.abs(gt[valid_idx_mask] - left_values)
        right_diffs = torch.abs(right_values - gt[valid_idx_mask])

        denom = left_diffs + right_diffs + 1e-12
        weight_right[valid_idx_mask] = left_diffs / denom
        weight_left[valid_idx_mask] = 1.0 - weight_right[valid_idx_mask]

    invalid_idx_mask_neg = indices < 0
    weight_right[invalid_idx_mask_neg] = 0.0
    weight_left[invalid_idx_mask_neg] = 1.0
    indices[invalid_idx_mask_neg] = 0.0

    invalid_idx_mask_pos = indices >= reg_max
    weight_right[invalid_idx_mask_pos] = 1.0
    weight_left[invalid_idx_mask_pos] = 0.0
    indices[invalid_idx_mask_pos] = reg_max - 0.1

    indices = torch.nan_to_num(indices, nan=0.0, posinf=reg_max - 0.1, neginf=0.0)
    weight_right = torch.nan_to_num(weight_right, nan=0.0, posinf=1.0, neginf=0.0)
    weight_left = torch.nan_to_num(weight_left, nan=0.0, posinf=1.0, neginf=0.0)

    return indices, weight_right, weight_left


def translate_gt_dynamic(gt, reg_max, reg_scale, up):
    """
    Dynamic target translation for ADM.

    Args:
        gt (Tensor): Shape [N].
        reg_max (int): Max index of discrete bins.
        reg_scale (Tensor or float): Curvature controller.
        up (Tensor): Shape [N] or [N, 1] (must be flattened per sample).

    Returns:
        indices, weight_right, weight_left
    """
    gt = gt.reshape(-1)

    if gt.numel() == 0:
        return gt, gt, gt

    gt = torch.nan_to_num(gt, nan=0.0, posinf=0.0, neginf=0.0)

    if up.dim() == 2 and up.shape[-1] == 1:
        up = up.squeeze(-1)
    elif up.dim() == 0:
        up = up.view(1)

    up = torch.nan_to_num(up.reshape(-1), nan=0.5, posinf=1.0, neginf=0.0).clamp(min=1e-6)

    # 对齐长度，避免动态 up 与 gt 数量不一致时直接崩溃
    if up.numel() != gt.numel():
        if up.numel() == 1:
            up = up.expand_as(gt)
        else:
            min_len = min(up.numel(), gt.numel())
            up = up[:min_len]
            gt = gt[:min_len]

    function_values = weighting_function_dynamic(reg_max, up, reg_scale)  # [N, K]

    # For each gt, find the left index using searchsorted
    indices = torch.searchsorted(
        function_values.contiguous(),
        gt.unsqueeze(-1),
        right=True,
    ).squeeze(-1) - 1

    indices = indices.float()
    weight_right = torch.zeros_like(indices)
    weight_left = torch.zeros_like(indices)

    valid_idx_mask = (indices >= 0) & (indices < reg_max)

    if valid_idx_mask.any():
        valid_indices = indices[valid_idx_mask].long()
        valid_rows = torch.nonzero(valid_idx_mask, as_tuple=False).squeeze(-1)

        left_values = function_values[valid_rows, valid_indices]
        right_values = function_values[valid_rows, valid_indices + 1]

        left_diffs = torch.abs(gt[valid_idx_mask] - left_values)
        right_diffs = torch.abs(right_values - gt[valid_idx_mask])

        denom = left_diffs + right_diffs + 1e-12
        weight_right[valid_idx_mask] = left_diffs / denom
        weight_left[valid_idx_mask] = 1.0 - weight_right[valid_idx_mask]

    invalid_idx_mask_neg = indices < 0
    weight_right[invalid_idx_mask_neg] = 0.0
    weight_left[invalid_idx_mask_neg] = 1.0
    indices[invalid_idx_mask_neg] = 0.0

    invalid_idx_mask_pos = indices >= reg_max
    weight_right[invalid_idx_mask_pos] = 1.0
    weight_left[invalid_idx_mask_pos] = 0.0
    indices[invalid_idx_mask_pos] = reg_max - 0.1

    indices = torch.nan_to_num(indices, nan=0.0, posinf=reg_max - 0.1, neginf=0.0)
    weight_right = torch.nan_to_num(weight_right, nan=0.0, posinf=1.0, neginf=0.0)
    weight_left = torch.nan_to_num(weight_left, nan=0.0, posinf=1.0, neginf=0.0)

    return indices, weight_right, weight_left


def distance2bbox(points, distance, reg_scale):
    """
    Decode edge distances into boxes in cxcywh format.

    Args:
        points (Tensor): Shape [..., 4], [cx, cy, w, h].
        distance (Tensor): Shape [..., 4], [left, top, right, bottom].
        reg_scale (Tensor or float): Regression scale.

    Returns:
        Tensor: Shape [..., 4], boxes in cxcywh format.
    """
    reg_scale_abs = torch.abs(_as_tensor_like(reg_scale, points)).clamp(min=1e-6)

    points = torch.nan_to_num(points, nan=0.5, posinf=1.0, neginf=0.0)
    distance = torch.nan_to_num(distance, nan=0.0, posinf=0.0, neginf=0.0)

    point_w = points[..., 2].clamp(min=1e-6)
    point_h = points[..., 3].clamp(min=1e-6)

    x1 = points[..., 0] - (0.5 * reg_scale_abs + distance[..., 0]) * (
        point_w / reg_scale_abs
    )
    y1 = points[..., 1] - (0.5 * reg_scale_abs + distance[..., 1]) * (
        point_h / reg_scale_abs
    )
    x2 = points[..., 0] + (0.5 * reg_scale_abs + distance[..., 2]) * (
        point_w / reg_scale_abs
    )
    y2 = points[..., 1] + (0.5 * reg_scale_abs + distance[..., 3]) * (
        point_h / reg_scale_abs
    )

    bboxes = torch.stack([x1, y1, x2, y2], dim=-1)
    bboxes = torch.nan_to_num(bboxes, nan=0.5, posinf=1.0, neginf=0.0)

    return box_xyxy_to_cxcywh(bboxes)


def bbox2distance(points, bbox, reg_max, reg_scale, up, eps=0.1):
    """
    Convert bbox to distance targets.

    Supports:
    1) fixed up: [1]
    2) dynamic up: [N, 1] or [N]
    3) empty matched targets: N == 0
    """
    # Empty case handling
    if points.numel() == 0 or bbox.numel() == 0:
        device = points.device
        dtype = points.dtype
        empty_target = torch.empty((0,), device=device, dtype=dtype)
        empty_weight_right = torch.empty((0,), device=device, dtype=dtype)
        empty_weight_left = torch.empty((0,), device=device, dtype=dtype)
        return empty_target, empty_weight_right, empty_weight_left

    points = torch.nan_to_num(points, nan=0.5, posinf=1.0, neginf=0.0)
    bbox = torch.nan_to_num(bbox, nan=0.5, posinf=1.0, neginf=0.0)

    reg_scale = torch.abs(_as_tensor_like(reg_scale, points)).clamp(min=1e-6)

    point_w = points[..., 2].clamp(min=1e-6)
    point_h = points[..., 3].clamp(min=1e-6)

    left = (points[:, 0] - bbox[:, 0]) / (point_w / reg_scale + 1e-16) - 0.5 * reg_scale
    top = (points[:, 1] - bbox[:, 1]) / (point_h / reg_scale + 1e-16) - 0.5 * reg_scale
    right = (bbox[:, 2] - points[:, 0]) / (point_w / reg_scale + 1e-16) - 0.5 * reg_scale
    bottom = (bbox[:, 3] - points[:, 1]) / (point_h / reg_scale + 1e-16) - 0.5 * reg_scale

    four_lens = torch.stack([left, top, right, bottom], -1)
    four_lens = torch.nan_to_num(four_lens, nan=0.0, posinf=0.0, neginf=0.0)

    # Determine if dynamic up is used
    dynamic_mode = False
    if torch.is_tensor(up):
        # If up has same number of elements as points, treat as dynamic
        if up.numel() == points.shape[0]:
            dynamic_mode = True
        # Or if up has batch dimension matching points batch size (flattened)
        elif up.dim() >= 2 and up.shape[0] == points.shape[0]:
            dynamic_mode = True

    if dynamic_mode:
        # Flatten up to [N] (N = total boxes)
        if up.dim() == 3 and up.shape[-1] == 1:
            up_flat = up.squeeze(-1).reshape(-1)
        elif up.dim() == 2:
            up_flat = up.reshape(-1)
        else:
            up_flat = up.reshape(-1)

        up_flat = torch.nan_to_num(up_flat, nan=0.5, posinf=1.0, neginf=0.0).clamp(min=1e-6)

        up_repeat = up_flat.unsqueeze(-1).repeat(1, 4).reshape(-1)
        four_lens_flat = four_lens.reshape(-1)

        four_lens_flat, weight_right, weight_left = translate_gt_dynamic(
            four_lens_flat,
            reg_max,
            reg_scale,
            up_repeat,
        )

        if reg_max is not None:
            four_lens_flat = four_lens_flat.clamp(min=0, max=reg_max - eps)

        return (
            four_lens_flat.detach(),
            weight_right.detach(),
            weight_left.detach(),
        )

    # Fixed up mode
    if torch.is_tensor(up) and up.numel() == 0:
        device = points.device
        dtype = points.dtype
        empty_target = torch.empty((0,), device=device, dtype=dtype)
        empty_weight_right = torch.empty((0,), device=device, dtype=dtype)
        empty_weight_left = torch.empty((0,), device=device, dtype=dtype)
        return empty_target, empty_weight_right, empty_weight_left

    four_lens, weight_right, weight_left = translate_gt(
        four_lens,
        reg_max,
        reg_scale,
        up,
    )

    if reg_max is not None:
        four_lens = four_lens.clamp(min=0, max=reg_max - eps)

    return (
        four_lens.reshape(-1).detach(),
        weight_right.detach(),
        weight_left.detach(),
    )
